﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace final
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCalculer_Click(object sender, EventArgs e)
        {

            double tp1;
            double tp2;
            double tp3;
            double exampr;
            double examfi;
            double total=0;
            double note=0;
            char lettre='E';

            if (double.TryParse(txtTP1.Text,out  tp1) )
            {
                if(tp1 < 0 || tp1 > 25)
                {
                    MessageBox.Show("Veillez entre une note normale pour le Tp1 comprise entre 0 et 25");
                    //txtTP1.Text = string.Empty;
                }
            }
            else
            {
                txtTP1.Text = string.Empty;
                MessageBox.Show("seul les chiffres entier sont autoriser veuiller resaisir une note correcte pour le tp1");
            }


            if (double.TryParse(txtTP2.Text, out tp2))
            {
                if (tp2 < 0 || tp2 > 35)
                {
                    MessageBox.Show("Veillez entre une note normale pour le Tp2 comprise entre 0 et 35");
                    //txtTP2.Text = string.Empty;
                }
            }
            else
            {
                txtTP2.Text = string.Empty;
                MessageBox.Show("seul les chiffres entier sont autoriser veuiller resaisir une note correcte pour le tp2");

            }


            if (double.TryParse(txtTp3.Text, out tp3))
            {
                if (tp3 < 0 || tp3 > 40)
                {
                    MessageBox.Show("Veillez entre une note normale pour le Tp3 comprise entre 0 et 40");
                    //txtTp3.Text = string.Empty;
                }
            }
            else
            {
                txtTp3.Text = string.Empty;
                MessageBox.Show("seul les chiffres entier sont autoriser veuiller resaisir une note correcte pour le tp3");
            }

            if (double.TryParse(txtExamenPr.Text, out exampr))
            {
                if (exampr < 0 || exampr > 100)
                {
                    MessageBox.Show("Veillez entre une note normale pour l#examen pratique comprise entre 0 et 100");
                   // txtExamenPr.Text = string.Empty;
                }
            }
            else
            {
                txtExamenPr.Text = string.Empty;
                MessageBox.Show("seul les chiffres entier sont autoriser veuiller resaisir une note correcte pour l'exame pratique");
            }


            if (double.TryParse(txtExamenFi.Text, out examfi))
            {
                if (examfi < 0 || examfi > 100)
                {
                    MessageBox.Show("Veillez entre une note normale pour l'examen final comprise entre 0 et 100");
                   // txtExamenFi.Text = string.Empty;
                }
            }
            else
            {
                txtExamenFi.Text = string.Empty;
                MessageBox.Show("seul les chiffres entier sont autoriser veuiller resaisir une note correcte pour l'exame finale");
            }

            double NAtp1 = (tp1 / 25) * 20;
            double NAtp2 = (tp2 / 35) * 20;
            double NAtp3 = (tp3 / 40) * 20;
            double NAexampr = (exampr / 100) * 20;
            double NAexamfi = (examfi / 100) * 20;
            total = (NAtp1*0.8 + NAtp2*0.7 + NAtp3*0.6)/2.1;
            note = ((NAtp1 + NAtp2 + NAtp3) * 0.4 + NAexampr * 0.2 + NAexamfi * 0.4) / 4;
            if(note>=0 && note<10)
            {
                lettre = 'E';
            }

            if (note >= 10 && note < 14)
            {
                lettre = 'D';
            }
            if (note >= 14 && note < 16)
            {
                lettre = 'C';
            }
            if (note >= 16 && note < 18)
            {
                lettre = 'B';
            }
            if (note >= 18)
            {
                lettre = 'A';
            }

            if (txtExamenFi.Text.Trim() != "" && txtExamenPr.Text.Trim() != "" && txtTP1.Text.Trim() != "" && txtTP2.Text.Trim() != "" && txtTp3.Text.Trim() != "")
            {
                //btnCalculer.Enabled = true;

                txtTotal.Text = total.ToString();
                txtNote.Text = note.ToString();
                txtLettre.Text = lettre.ToString();
            }

            btnQuitter.BackColor = Color.Red;
            btnQuitter.ForeColor = Color.Black;
            btnEffacer.BackColor = Color.White;
        }

        private void txtTP1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnEffacer_Click(object sender, EventArgs e)
        {
            foreach(Control ctrl in this.Controls)
            {
                if(ctrl is TextBox)
                {
                    ((TextBox)ctrl).Text = string.Empty;
                }
            }
        }

        private void btnQuitter_Click(object sender, EventArgs e)
        {
            Application.Exit();
            //DialogResult result = MessageBox.Show("voulez vous sortir ;", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            //if (result = DialogResult.Yes)
            //{
            //    Application.Exit();
            //}
        }

        private void txtNote_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
