﻿namespace final
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTP1 = new System.Windows.Forms.Label();
            this.lblPT2 = new System.Windows.Forms.Label();
            this.lblTP3 = new System.Windows.Forms.Label();
            this.lblExamenPr = new System.Windows.Forms.Label();
            this.lblExamenFi = new System.Windows.Forms.Label();
            this.lblNote = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            this.lblLettre = new System.Windows.Forms.Label();
            this.txtTP1 = new System.Windows.Forms.TextBox();
            this.txtTp3 = new System.Windows.Forms.TextBox();
            this.txtTP2 = new System.Windows.Forms.TextBox();
            this.txtExamenPr = new System.Windows.Forms.TextBox();
            this.txtExamenFi = new System.Windows.Forms.TextBox();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.txtNote = new System.Windows.Forms.TextBox();
            this.txtLettre = new System.Windows.Forms.TextBox();
            this.btnEffacer = new System.Windows.Forms.Button();
            this.btnQuitter = new System.Windows.Forms.Button();
            this.btnCalculer = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblTP1
            // 
            this.lblTP1.AutoSize = true;
            this.lblTP1.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTP1.Location = new System.Drawing.Point(87, 74);
            this.lblTP1.Name = "lblTP1";
            this.lblTP1.Size = new System.Drawing.Size(37, 19);
            this.lblTP1.TabIndex = 0;
            this.lblTP1.Text = "TP1";
            // 
            // lblPT2
            // 
            this.lblPT2.AutoSize = true;
            this.lblPT2.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPT2.Location = new System.Drawing.Point(87, 168);
            this.lblPT2.Name = "lblPT2";
            this.lblPT2.Size = new System.Drawing.Size(37, 19);
            this.lblPT2.TabIndex = 0;
            this.lblPT2.Text = "TP2";
            // 
            // lblTP3
            // 
            this.lblTP3.AutoSize = true;
            this.lblTP3.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTP3.Location = new System.Drawing.Point(87, 287);
            this.lblTP3.Name = "lblTP3";
            this.lblTP3.Size = new System.Drawing.Size(37, 19);
            this.lblTP3.TabIndex = 0;
            this.lblTP3.Text = "TP3";
            // 
            // lblExamenPr
            // 
            this.lblExamenPr.AutoSize = true;
            this.lblExamenPr.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExamenPr.Location = new System.Drawing.Point(584, 72);
            this.lblExamenPr.Name = "lblExamenPr";
            this.lblExamenPr.Size = new System.Drawing.Size(165, 18);
            this.lblExamenPr.TabIndex = 0;
            this.lblExamenPr.Text = "EXAMEN PRATIQUE";
            // 
            // lblExamenFi
            // 
            this.lblExamenFi.AutoSize = true;
            this.lblExamenFi.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExamenFi.Location = new System.Drawing.Point(622, 214);
            this.lblExamenFi.Name = "lblExamenFi";
            this.lblExamenFi.Size = new System.Drawing.Size(127, 18);
            this.lblExamenFi.TabIndex = 0;
            this.lblExamenFi.Text = "EXAMEN FINAL";
            // 
            // lblNote
            // 
            this.lblNote.AutoSize = true;
            this.lblNote.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNote.Location = new System.Drawing.Point(584, 297);
            this.lblNote.Name = "lblNote";
            this.lblNote.Size = new System.Drawing.Size(135, 18);
            this.lblNote.TabIndex = 0;
            this.lblNote.Text = "NOTE GLOBALE";
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Font = new System.Drawing.Font("Algerian", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal.Location = new System.Drawing.Point(134, 406);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(86, 19);
            this.lblTotal.TabIndex = 0;
            this.lblTotal.Text = "TOTAL TP";
            // 
            // lblLettre
            // 
            this.lblLettre.AutoSize = true;
            this.lblLettre.Font = new System.Drawing.Font("Algerian", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLettre.Location = new System.Drawing.Point(700, 406);
            this.lblLettre.Name = "lblLettre";
            this.lblLettre.Size = new System.Drawing.Size(184, 19);
            this.lblLettre.TabIndex = 0;
            this.lblLettre.Text = "LETTRE A ATTRIBUER";
            // 
            // txtTP1
            // 
            this.txtTP1.Font = new System.Drawing.Font("Algerian", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTP1.Location = new System.Drawing.Point(186, 64);
            this.txtTP1.Name = "txtTP1";
            this.txtTP1.Size = new System.Drawing.Size(115, 38);
            this.txtTP1.TabIndex = 1;
            this.txtTP1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtTP1.TextChanged += new System.EventHandler(this.txtTP1_TextChanged);
            // 
            // txtTp3
            // 
            this.txtTp3.Font = new System.Drawing.Font("Algerian", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTp3.Location = new System.Drawing.Point(186, 277);
            this.txtTp3.Name = "txtTp3";
            this.txtTp3.Size = new System.Drawing.Size(115, 38);
            this.txtTp3.TabIndex = 1;
            this.txtTp3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtTP2
            // 
            this.txtTP2.Font = new System.Drawing.Font("Algerian", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTP2.Location = new System.Drawing.Point(186, 158);
            this.txtTP2.Name = "txtTP2";
            this.txtTP2.Size = new System.Drawing.Size(115, 38);
            this.txtTP2.TabIndex = 1;
            this.txtTP2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtExamenPr
            // 
            this.txtExamenPr.Font = new System.Drawing.Font("Algerian", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtExamenPr.Location = new System.Drawing.Point(782, 64);
            this.txtExamenPr.Name = "txtExamenPr";
            this.txtExamenPr.Size = new System.Drawing.Size(123, 38);
            this.txtExamenPr.TabIndex = 1;
            this.txtExamenPr.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtExamenFi
            // 
            this.txtExamenFi.Font = new System.Drawing.Font("Algerian", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtExamenFi.Location = new System.Drawing.Point(782, 206);
            this.txtExamenFi.Name = "txtExamenFi";
            this.txtExamenFi.Size = new System.Drawing.Size(123, 38);
            this.txtExamenFi.TabIndex = 1;
            this.txtExamenFi.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtExamenFi.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // txtTotal
            // 
            this.txtTotal.BackColor = System.Drawing.Color.Aqua;
            this.txtTotal.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTotal.Font = new System.Drawing.Font("Algerian", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotal.ForeColor = System.Drawing.Color.Blue;
            this.txtTotal.Location = new System.Drawing.Point(138, 484);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.Size = new System.Drawing.Size(100, 23);
            this.txtTotal.TabIndex = 2;
            this.txtTotal.Text = "  ";
            this.txtTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtNote
            // 
            this.txtNote.BackColor = System.Drawing.Color.Aqua;
            this.txtNote.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNote.Font = new System.Drawing.Font("Algerian", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNote.ForeColor = System.Drawing.Color.Blue;
            this.txtNote.Location = new System.Drawing.Point(784, 297);
            this.txtNote.Name = "txtNote";
            this.txtNote.Size = new System.Drawing.Size(100, 23);
            this.txtNote.TabIndex = 2;
            this.txtNote.Text = "  ...";
            this.txtNote.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtNote.TextChanged += new System.EventHandler(this.txtNote_TextChanged);
            // 
            // txtLettre
            // 
            this.txtLettre.BackColor = System.Drawing.Color.Aqua;
            this.txtLettre.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtLettre.Font = new System.Drawing.Font("Algerian", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLettre.ForeColor = System.Drawing.Color.Blue;
            this.txtLettre.Location = new System.Drawing.Point(739, 484);
            this.txtLettre.Name = "txtLettre";
            this.txtLettre.Size = new System.Drawing.Size(100, 23);
            this.txtLettre.TabIndex = 2;
            this.txtLettre.Text = "  ...";
            this.txtLettre.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnEffacer
            // 
            this.btnEffacer.BackColor = System.Drawing.Color.Aqua;
            this.btnEffacer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEffacer.Font = new System.Drawing.Font("Microsoft YaHei", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEffacer.ForeColor = System.Drawing.Color.Black;
            this.btnEffacer.Location = new System.Drawing.Point(482, 591);
            this.btnEffacer.Name = "btnEffacer";
            this.btnEffacer.Size = new System.Drawing.Size(133, 51);
            this.btnEffacer.TabIndex = 3;
            this.btnEffacer.Text = "Effacer";
            this.btnEffacer.UseVisualStyleBackColor = false;
            this.btnEffacer.Click += new System.EventHandler(this.btnEffacer_Click);
            // 
            // btnQuitter
            // 
            this.btnQuitter.BackColor = System.Drawing.Color.Aqua;
            this.btnQuitter.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnQuitter.Font = new System.Drawing.Font("Microsoft YaHei", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuitter.ForeColor = System.Drawing.Color.Red;
            this.btnQuitter.Location = new System.Drawing.Point(809, 591);
            this.btnQuitter.Name = "btnQuitter";
            this.btnQuitter.Size = new System.Drawing.Size(133, 51);
            this.btnQuitter.TabIndex = 3;
            this.btnQuitter.Text = " ";
            this.btnQuitter.UseVisualStyleBackColor = false;
            this.btnQuitter.Click += new System.EventHandler(this.btnQuitter_Click);
            // 
            // btnCalculer
            // 
            this.btnCalculer.BackColor = System.Drawing.Color.Aqua;
            this.btnCalculer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCalculer.Font = new System.Drawing.Font("Microsoft YaHei", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalculer.ForeColor = System.Drawing.Color.Black;
            this.btnCalculer.Location = new System.Drawing.Point(127, 591);
            this.btnCalculer.Name = "btnCalculer";
            this.btnCalculer.Size = new System.Drawing.Size(151, 51);
            this.btnCalculer.TabIndex = 3;
            this.btnCalculer.Text = "calculer";
            this.btnCalculer.UseVisualStyleBackColor = false;
            this.btnCalculer.Click += new System.EventHandler(this.btnCalculer_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Aqua;
            this.ClientSize = new System.Drawing.Size(1102, 708);
            this.Controls.Add(this.btnCalculer);
            this.Controls.Add(this.btnQuitter);
            this.Controls.Add(this.btnEffacer);
            this.Controls.Add(this.txtLettre);
            this.Controls.Add(this.txtNote);
            this.Controls.Add(this.txtTotal);
            this.Controls.Add(this.txtExamenFi);
            this.Controls.Add(this.txtExamenPr);
            this.Controls.Add(this.txtTP2);
            this.Controls.Add(this.txtTp3);
            this.Controls.Add(this.txtTP1);
            this.Controls.Add(this.lblLettre);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.lblNote);
            this.Controls.Add(this.lblExamenFi);
            this.Controls.Add(this.lblExamenPr);
            this.Controls.Add(this.lblTP3);
            this.Controls.Add(this.lblPT2);
            this.Controls.Add(this.lblTP1);
            this.Name = "Form1";
            this.ShowIcon = false;
            this.Text = "RELEVE DE NOTE PAM";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTP1;
        private System.Windows.Forms.Label lblPT2;
        private System.Windows.Forms.Label lblTP3;
        private System.Windows.Forms.Label lblExamenPr;
        private System.Windows.Forms.Label lblExamenFi;
        private System.Windows.Forms.Label lblNote;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Label lblLettre;
        private System.Windows.Forms.TextBox txtTP1;
        private System.Windows.Forms.TextBox txtTp3;
        private System.Windows.Forms.TextBox txtTP2;
        private System.Windows.Forms.TextBox txtExamenPr;
        private System.Windows.Forms.TextBox txtExamenFi;
        private System.Windows.Forms.TextBox txtTotal;
        private System.Windows.Forms.TextBox txtNote;
        private System.Windows.Forms.TextBox txtLettre;
        private System.Windows.Forms.Button btnEffacer;
        private System.Windows.Forms.Button btnQuitter;
        private System.Windows.Forms.Button btnCalculer;
    }
}

